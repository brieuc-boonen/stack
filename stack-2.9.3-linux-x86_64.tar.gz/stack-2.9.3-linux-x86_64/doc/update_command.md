<div class="hidden-warning"><a href="https://docs.haskellstack.org/"><img src="https://cdn.jsdelivr.net/gh/commercialhaskell/stack/doc/img/hidden-warning.svg"></a></div>

# The `stack update` command

~~~text
stack update
~~~

Generally, Stack automatically updates the package index when necessary.

`stack update` will download the most recent set of packages from your package
indices (e.g. Hackage).
