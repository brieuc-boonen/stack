<div class="hidden-warning"><a href="https://docs.haskellstack.org/"><img src="https://cdn.jsdelivr.net/gh/commercialhaskell/stack/doc/img/hidden-warning.svg"></a></div>

# The `stack purge` command

~~~text
stack purge
~~~

`stack purge` has the same effect as, and is provided as a shorthand for,
[`stack clean --full`](clean_command.md).
