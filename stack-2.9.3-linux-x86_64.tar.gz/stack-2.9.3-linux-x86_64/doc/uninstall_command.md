<div class="hidden-warning"><a href="https://docs.haskellstack.org/"><img src="https://cdn.jsdelivr.net/gh/commercialhaskell/stack/doc/img/hidden-warning.svg"></a></div>

# The `stack uninstall` command

~~~text
stack uninstall
~~~

`stack uninstall` provides information about how to uninstall Stack. It does not
itself uninstall Stack.
