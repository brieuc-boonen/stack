<div class="hidden-warning"><a href="https://docs.haskellstack.org/"><img src="https://cdn.jsdelivr.net/gh/commercialhaskell/stack/doc/img/hidden-warning.svg"></a></div>

# The `stack unpack` command

~~~text
stack unpack PACKAGE [--to ARG]
~~~

`stack unpack` downloads a tarball for the specified package and unpacks it.

Pass the option `--to <directory>` to specify the destination directory.
