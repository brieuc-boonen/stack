<div class="hidden-warning"><a href="https://docs.haskellstack.org/"><img src="https://cdn.jsdelivr.net/gh/commercialhaskell/stack/doc/img/hidden-warning.svg"></a></div>

# The `stack hoogle` command

~~~text
stack hoogle [-- ARGUMENT(S) (e.g. 'stack hoogle -- server --local')]
             [--[no-]setup] [--rebuild] [--server]
~~~

Hoogle is a Haskell API search engine. `stack hoogle` runs Hoogle.
